# Alex Rivera - Personal Portfolio Website

Generated using **Portfolio Builder**.

## 📁 Package Contents
- `index.html` - Static HTML5 website
- `css/style.css` & `responsive.css` - Custom styling
- `js/script.js` - Interactivity
- `assets/` - Image & font assets
- `README.md` - Host instructions

## 🚀 How to Host
Deploy to GitHub Pages, Netlify, Vercel, or cPanel by uploading the contents of this folder!
